from .resource_manager import load_stylesheet
